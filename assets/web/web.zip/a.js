// alert(123);
console.log(123);